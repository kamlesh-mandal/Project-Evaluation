export class Login {
    constructor(
       public userName:string,
       public password:string,

    ){}
}
